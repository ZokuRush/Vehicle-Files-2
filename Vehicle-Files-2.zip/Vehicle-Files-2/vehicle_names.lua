Citizen.CreateThread(function()
    AddTextEntry('MODEL NAME', 'VEHICLE NAME')
end)
